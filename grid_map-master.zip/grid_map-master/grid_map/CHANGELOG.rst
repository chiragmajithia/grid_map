^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package grid_map
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------
* Separated OpenCV to grid map conversions to grid_map_cv package. The new methods
  are more generalized, faster, and can be used without ROS message types.
* Contributors: Peter Fankhauser

1.2.0 (2016-03-03)
------------------
* Added new package grid_map as metapackage (`#34 <https://github.com/ethz-asl/grid_map/issues/34>`_).
